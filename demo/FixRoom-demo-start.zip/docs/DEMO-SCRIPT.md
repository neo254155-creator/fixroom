# FixRoom: two-minute demo

Before recording, start the Spring Boot app with `./scripts/start.ps1`. Keep Switch Console open. Use a fresh copy of the project for each rehearsal; the submitted source deliberately starts with the bug.

1. Show Discord's fixroom channel and the FixRoom agent registered in Switch with the project as its directory.
2. Send: `@fixroom-fixer A 10000-cent checkout with a 10% coupon should total 9000 cents, but it totals 9900. Please reproduce it, propose a fix, and wait for my approval.`
3. Show the agent's reproduction output and proposal. The baseline is eight checkout tests, with three failures.
4. Show the awaiting incident with `./scripts/incident.ps1 status -Id FIX-001`. Note that the source is unchanged.
5. In the same Discord thread, send: `@fixroom-fixer APPROVE FIX-001`.
6. Show the real Java source correction and the agent's final verification: eight tests passed, none skipped.
7. Open `artifacts/FIX-001/resolution.md`: timestamped reproduction, proposal, approval and verification.

Suggested narration: "FixRoom brings a coding teammate into Discord through Switch. It reproduces a reported bug, asks the owner before editing, and returns executable test evidence. Switch carries the conversation and owner context; Spring Boot records the workflow and runs the checks."

The sample bug is intentionally seeded. Label it as a demonstration fixture. Do not claim the app fixed a real production incident or that the approval API independently authenticates Discord users.
