# Verified implementation, November 7, 2026

The project was checked on Windows with Java 23.0.1, Spring Boot 4.1.2 and the bundled Maven Wrapper.

- Workflow unit tests and Spring context startup: **9 tests passed**, no failures or skips.
- An isolated source copy was launched on loopback port 8088 for a real HTTP/Maven rehearsal.
- Seeded checkout HTTP response: **9900** cents for a 10000-cent subtotal and 10-percent coupon.
- Invalid negative subtotal: **HTTP 400**.
- Reproduction API launched Maven and parsed a new Surefire report: **8 tests, 3 failures, 0 errors, 0 skipped**.
- Verification before approval: **HTTP 409**.
- Wrong approval confirmation: **HTTP 400**.
- A synthetic test-operator approval was recorded only in the isolated rehearsal.
- The denominator was corrected only in that source copy.
- Verification API launched Maven again: **8 tests passed**, no failures, errors or skips.
- Full repaired suite and executable JAR build: **17 tests passed**.
- After stopping, rebuilding and restarting the rehearsal server: checkout response **9000** cents; incident persisted as **VERIFIED**.
- The original delivered project was left with the seeded bug and no demo incidents, then started on **127.0.0.1:8087**; health returned UP and quote returned the expected seeded 9900.
- Windows PowerShell start and incident health helper scripts were exercised.

Raw before/after Maven logs and the resolution are in `rehearsal-evidence/`. They are explicitly **automated local rehearsal evidence**, not proof of a completed Discord/Switch chat run or a real person's approval. The final live chat still requires registering/inviting the dedicated coding agent and running the report/approval sequence through Switch.

Windows packaging check found that a running JAR must be stopped before rebuilding it. The README documents the stop/rebuild/start sequence.
